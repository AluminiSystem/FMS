<?php

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $err = "";
    include 'dbconnect.php';
    $uname = $_POST['uname'];
    $pass = $_POST['pass'];

    // $sql = "SELECT * FROM `signupinfo` WHERE `username`='$uname' AND `password`='$pass'"; 
    $sql = "Select * From signupinfo Where username='$uname' AND password='$pass'";
    $result = mysqli_query($conn, $sql);
    $num = mysqli_num_rows($result);
 
    if($num == 1){
            echo '<script>alert("Congratulations! You are logged in. Welcome to the Food Management System")</script>';
            session_start();
            $_SESSION['loggedin'] = true;
            $_SESSION['uname'] = $uname;
            header("location: donar.php");
    }
    else{
        echo '<script>alert("Sorry! Please Check your Username and Password")</script>';
    }
    
}

?>

<!DOCTYPE html>
<html lang="en">
<?php
        $sublink_a = "/FMS/sublinks/home.php";
        $sublink_b = "/FMS/sublinks/about.php";
        $sublink_c = "/FMS/sublinks/contact.php";
        $sublink_d = "/FMS/sublinks/donar.php";
        $sublink_e = "/FMS/sublinks/signup.php";
        $sublink_f = "https://www.actionagainsthunger.org/the-hunger-crisis/world-hunger-facts/";
        $sublink_g = "/FMS/sublinks/foodlist.php";
        $sublink_h = "/FMS/sublinks/login.php";
        $sublink_i = "/FMS/sublinks/forgotpass.php";
    ?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Food Management</title>
    <link rel="stylesheet" href="/FMS/sublinks/fmsform.css">
    <link rel="stylesheet" href="/FMS/fms.css">
</head>
<body>
    <div class="login">

        <!-- <div class="head">
            <ul class="dashboard">
                        <li class="dash"><a href="<?php echo $sublink_a; ?>" class="sublink">Home</a></li>
                        <li class="dash"><a href="<?php echo $sublink_b; ?>" class="sublink">About</a></li>
                        <li class="dash"><a href="<?php echo $sublink_d; ?>" class="sublink">Donar</a></li>
                        <li class="dash"><a href="<?php echo $sublink_g; ?>" class="sublink">Available Food List</a></li>
                        <li class="dash"><a href="<?php echo $sublink_c; ?>" class="sublink">Contact</a></li>
                        <li class="dash"><a href="<?php echo $sublink_e; ?>" class="sublink sublink1">Register/Login</a></li>
            </ul>
        </div>     -->
    <div class="loginpage">   
        <h2 class="forminfohead">Login</h2>
        <div class="forminfo">
            <form class="loginform" action="\FMS\sublinks\login.php" method="post">
            <div class="forminfo1">
                <div class="label">
                    <label for="uname" class="label1">Username</label>
                </div>
                <div class="input">
                    <input type="text" placeholder="Enter Username" name="uname" required>
                </div>

                <div class="label">
                    <label for="pass" class="label1">Password</label>
                </div>
                <div class="input">
                    <input type="password" placeholder="Enter Password" name="pass" required>
                </div>

                <button type="submit" class="btn">Login</button>
            </div>
            </form>
        </div>
            <div class="loglink">
                <a href="<?php echo $sublink_i;?>" class="forgot">Forgot Password?</a>

                <div class="homeicon">
                <a href="<?php echo $sublink_a; ?>" class="logoutlink"><img src="/FMS/images/home1.png" height="20px"
                width="20px" class="homeimg"></a>
            </div>
            </div>
            
    </div>

    </div>
</body>
</html>