<!DOCTYPE html>
<html lang="en">
<?php
        $sublink_a = "/FMS/sublinks/home.php";
        $sublink_b = "/FMS/sublinks/about.php";
        $sublink_c = "/FMS/sublinks/contact.php";
        $sublink_d = "/FMS/sublinks/donar.php";
        $sublink_e = "/FMS/sublinks/reglog.php";
        $sublink_f = "https://www.actionagainsthunger.org/the-hunger-crisis/world-hunger-facts/";
        $sublink_g = "/FMS/sublinks/foodlist.php";
    ?>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us | Food Management</title>
  <link rel="stylesheet" href="/FMS/fms.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>

  <div class="contcontainer continer">
    <div class="head">
    <ul class="dashboard">
                <li class="dash"><a href="<?php echo $sublink_a; ?>" class="sublink">Home</a></li>
                <li class="dash"><a href="<?php echo $sublink_b; ?>" class="sublink">About</a></li>
                <li class="dash"><a href="<?php echo $sublink_d; ?>" class="sublink">Donar</a></li>
                <li class="dash"><a href="<?php echo $sublink_g; ?>" class="sublink">Available Food List</a></li>
                <li class="dash"><a href="<?php echo $sublink_c; ?>" class="sublink">Contact</a></li>
                <li class="dash"><a href="<?php echo $sublink_e; ?>" class="sublink sublink1">Register/Login</a></li>
            </ul>
    </div>


<div class="signup container">
  <h2 style="text-align: center; margin:40px;" class="signuphead">Signup to Donate Food</h2>
 
 
 
 
 
 
 
 
 
 
 
 
 
 
  <!-- <form action="/FMS/sublinks/contact.php" method="post">
        <div class="mt-3 mx-5">
          <label for="name" class="form-label">Username</label>
          <input type="text" name="name" class="form-control" id="name" aria-describedby="emailHelp">
        </div>

        <div class="mt-2 mx-5 ">
          <label for="date" class="form-label">DOB</label>
          <input type="date" name="date" class="form-control" id="date" aria-describedby="emailHelp">
        </div>

        <div class="mt-3">
          <label for="email" class="form-label">Email</label>
          <input type="email" name="email" class="form-control" id="email" aria-describedby="emailHelp">
          <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
        </div>

        <div class="mt-3">
          <label for="phone" class="form-label">Phone Number</label>
          <input type="tel" name="phone" class="form-control" id="phone" aria-describedby="emailHelp">
        </div>

        <div class="mt-3">
          <label for="phone" class="form-label">Password</label>
          <input type="tel" name="phone" class="form-control" id="phone" aria-describedby="emailHelp">
        </div>

        <div class="mt-3">
          <label for="phone" class="form-label">Confirm Password</label>
          <input type="tel" name="phone" class="form-control" id="phone" aria-describedby="emailHelp">
          <div id="emailHelp" class="form-text">Make sure to type the same password</div>
        </div>

        <button type="submit" class="btn btn-primary mt-3">Submit</button>
      </form> -->
</div>

      <div class="end">
            <div class="fms">
                <h1>FOOD</h1>
                <h1>MANAGEMENT</h1>
            </div>

            <div class="endlinks">
                <ul>
                    <li class="endlink"><a href="<?php echo $sublink_b; ?>" class="endlinks1">About Us</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_c; ?>" class="endlinks1">Contact</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_d; ?>" class="endlinks1">Donor</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_f; ?>" target="_main" class="endlinks1">Hunger Fact</a></li>
                </ul>
            </div>

            <div class="follow" style="padding-left: ;float: right;margin-left: 40%;margin-top: 5%;">
            <nav class="media">
                <!-- <h3 style="color:white; font-size:20px;">Follow Us</h3> -->
                <!-- <a href="https://in.linkedin.com/in/vishal-burud?original_referer=https%3A%2F%2Fwww.google.com%2F" target="_main"><img src="/linkdin.png"></a> -->
                <a href="mailto:burudvishal07@gmail.com" target="_main"><img src="/FMS/follow/mail.png"></a>
                <a href="https://www.instagram.com/vishalburud.81/" target="_main"><img src="/FMS/follow/insta.png"></a>
                <a href="https://www.instagram.com/vishalburud.81/" target="_main"><img src="/FMS/follow/facebook.png"></a>
                <a href="" target="_main"><img src="/FMS/follow/twitter.png"></a>
                <!-- <a href="tel:+91 7218655640"><img src="/call.png"></a> -->
            </nav>
        </div>
      </div>

    </div>

    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script> -->
    <!-- <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script> -->
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script> -->
    
  </body>
</html>









</body>
</html>