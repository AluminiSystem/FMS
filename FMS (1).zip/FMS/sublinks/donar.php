<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: login.php");
    exit;
}

//Connect to database
$servername = "localhost";
$username = "root";
$password = "";
$database = "fms";
$conn = mysqli_connect($servername, $username, $password, $database);
?>

<!DOCTYPE html>
<html lang="en">
        <?php
            $sublink_a = "/FMS/sublinks/home.php";
            $sublink_b = "/FMS/sublinks/about.php";
            $sublink_c = "/FMS/sublinks/contact.php";
            $sublink_d = "/FMS/sublinks/donar.php";
            $sublink_e = "/FMS/sublinks/signup.php";
            $sublink_f = "https://www.actionagainsthunger.org/the-hunger-crisis/world-hunger-facts/";
            $sublink_g = "/FMS/sublinks/foodlist.php";
            $sublink_h = "/FMS/sublinks/login.php";
            $sublink_i = "/FMS/sublinks/logout.php";
        ?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donar | Food Management</title>
    <link rel="stylesheet" href="\FMS\fms.css">
    <link rel="stylesheet" href="\FMS\sublinks\donarfmsform.css">
</head>
<body>
         <div class="head">
            <ul class="dashboard">
                <li class="dash"><a href="<?php echo $sublink_a; ?>" class="sublink">Home</a></li>
                <li class="dash"><a href="<?php echo $sublink_b; ?>" class="sublink">About</a></li>
                <li class="dash"><a href="<?php echo $sublink_h; ?>" class="sublink">Donar</a></li>
                <li class="dash"><a href="<?php echo $sublink_g; ?>" class="sublink">Available Food List</a></li>
                <li class="dash"><a href="<?php echo $sublink_c; ?>" class="sublink">Contact</a></li>
                <li class="dash"><a href="<?php echo $sublink_e; ?>" class="sublink sublink1">Register/Login</a></li>
            </ul>
        </div>
    
    <?php
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $food_item = $_POST['fooditem'];
        $pickup_date = $_POST['pickupdate'];
        $pickup_address = $_POST['address'];
        $city = $_POST['city'];
        $state = $_POST['state'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $message = $_POST['msg'];
    
    
        //conecting to the database
        // $servername = "localhost";
        // $username = "root";
        // $password = "";
        // $database = "fms";
        // $conn = mysqli_connect($servername, $username, $password, $database);
    
        if(!$conn){
            die("Sorry We failed to Connect : " .mysqli_connect_error());
        }
        else{
            // echo "The Connection is Successfull!<br>";
    
            //submit these to database
            $sql = "INSERT INTO `donar` (`food_item`, `pickup_date`, `pickup_address`, `city`, `state`, `phone`, `email`, `message`, `time_stamp`) VALUES ('$food_item', '$pickup_date', '$pickup_address', '$city', '$state', '$phone', '$email', '$message', current_timestamp())";
            $result = mysqli_query($conn, $sql);
            if($result){
                // echo '<div class="alert alert-success alert-dismissible fade show" role="alert" color-green>
                // <strong>Success!</strong> Your Details are Submitted Successfully!.
                // <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                // </div>';
    
                echo '<script>alert("Success! Your Details are Submitted Successfully!")</script>';
            }
            else{
                echo "Data has Not inserted Successfully! bcz of this error------->" . mysqli_error($conn);
            }
        }
    }
    ?>

    <h2 class="forminfohead">Welcome! <?php echo $_SESSION['uname']?>, now you can Donate Your Food</h2>
        <div class="forminfo">
            <form action="\FMS\sublinks\donar.php" method="post">
            <div class="forminfo1 donarform">
                <div class="label">
                    <label for="fooditem" class="label1">Food Items</label>
                </div>
                <div class="input">
                    <input type="text" placeholder="Enter Food Items" name="fooditem" id="fooditem" required>
                </div>

                <div class="label">
                    <label for="pickupdate" class="label1">Pickup Date</label>
                </div>
                <div class="input">
                    <input type="date" placeholder="Enter Date for Pickup" name="pickupdate" required>
                </div>

                <div class="label">
                    <label for="address" class="label1">Pickup Address</label>
                </div>
                <div class="input">
                <textarea class="" name="address" id="address" name="address" cols="30" rows="2" required></textarea>
                </div>

                <div class="label">
                    <label for="city" class="label1">Choose City</label>
                </div>
                <div class="input">
                    <input type="city" placeholder="Enter Your City" name="city" required>
                </div>

                <div class="label">
                    <label for="state" class="label1">Choose State</label>
                </div>
                <div class="input">
                    <input type="state" placeholder="Enter Your City" name="state" required>
                </div>

                <div class="label">
                    <label for="phone" class="label1">Contact Number</label>
                </div>
                <div class="input">
                    <input type="tel" placeholder="Enter Contact Number" name="phone" required>
                </div>

                <div class="label">
                    <label for="email" class="label1">Email</label>
                </div>
                <div class="input">
                    <input type="email" placeholder="Enter Email Address" name="email" required>
                </div>

                <div class="label">
                    <label for="msg" class="label1">Your Message</label>
                </div>
                <div class="input">
                <textarea class="" name="msg" id="msg" name="msg" cols="30" rows="2" required></textarea>
                </div>

                <button type="submit" class="btn">Submit</button>

                <div class="logout">
                    <div class="log">
                        <a href="<?php echo $sublink_i; ?>" class="logoutlink">Logout</a>
                    </div> 
                     <pre> | </pre>
                    <div class="homeicon">
                        <a href="<?php echo $sublink_a; ?>" class="logoutlink"><img src="/FMS/images/home1.png" height="20px"
                        width="20px"></a>
                    </div>
                </div>

            </div>
            </form>
        </div>
    
        
    
        <div class="end">
            <div class="fms">
                <h1>FOOD</h1>
                <h1>MANAGEMENT</h1>
            </div>
    
            <div class="endlinks">
                <ul>
                    <li class="endlink"><a href="<?php echo $sublink_b; ?>" class="endlinks1">About Us</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_c; ?>" class="endlinks1">Contact</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_d; ?>" class="endlinks1">Donor</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_f; ?>" target="_main" class="endlinks1">Hunger Fact</a></li>
                </ul>
            </div>
    
            <div class="follow" style="padding-left: ;float: right;margin-left: 40%;margin-top: 5%;">
                <nav class="media">
                    <!-- <h3 style="color:white; font-size:20px;">Follow Us</h3> -->
                    <!-- <a href="https://in.linkedin.com/in/vishal-burud?original_referer=https%3A%2F%2Fwww.google.com%2F" target="_main"><img src="/linkdin.png"></a> -->
                    <a href="mailto:burudvishal07@gmail.com" target="_main"><img src="/FMS/follow/mail.png"></a>
                    <a href="https://www.instagram.com/vishalburud.81/" target="_main"><img src="/FMS/follow/insta.png"></a>
                    <a href="https://www.instagram.com/vishalburud.81/" target="_main"><img src="/FMS/follow/facebook.png"></a>
                    <a href="" target="_main"><img src="/FMS/follow/twitter.png"></a>
                    <!-- <a href="tel:+91 7218655640"><img src="/call.png"></a> -->
                </nav>
            </div>
        </div>
    
</body>
</html>