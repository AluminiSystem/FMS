<!DOCTYPE html>
<html lang="en">
<?php
        $sublink_a = "/FMS/sublinks/home.php";
        $sublink_b = "/FMS/sublinks/about.php";
        $sublink_c = "/FMS/sublinks/contact.php";
        $sublink_d = "/FMS/sublinks/donar.php";
        $sublink_e = "/FMS/sublinks/signup.php";
        $sublink_f = "https://www.actionagainsthunger.org/the-hunger-crisis/world-hunger-facts/";
        $sublink_g = "/FMS/sublinks/foodlist.php";
        $sublink_h = "/FMS/sublinks/login.php";
    ?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About | Food Management</title>
    <link rel="stylesheet" href="/FMS/fms.css">
</head>
<body>
    <div class="abtcontainer">
        <div class="head">
        <ul class="dashboard">
                <li class="dash"><a href="<?php echo $sublink_a; ?>" class="sublink">Home</a></li>
                <li class="dash"><a href="<?php echo $sublink_b; ?>" class="sublink">About</a></li>
                <li class="dash"><a href="<?php echo $sublink_h; ?>" class="sublink">Donar</a></li>
                <li class="dash"><a href="<?php echo $sublink_g; ?>" class="sublink">Available Food List</a></li>
                <li class="dash"><a href="<?php echo $sublink_c; ?>" class="sublink">Contact</a></li>
                <li class="dash"><a href="<?php echo $sublink_e; ?>" class="sublink sublink1">Register/Login</a></li>
            </ul>
        </div>

        <div class="about">
            <div class="abtimg">
                <img src="/FMS/images/helping.jpg" height="350px" width="100%">
            </div>
            <div class="abtinfo">
                <p class="abtinfo1">
                    In this system, we have tried to reduce leftover Food of Restaurant, Hotel, Mess, functions/Events by giving<br>
                    that food to NGO's or Needy people. In this system we use donated food to feed the Hungry or Elder people.<br>
                    Our motive of this system is to generate awareness about food 
                </p>
                <p class="abtinfo2 font">
                    <h3 class="abtinfo2head">How it Works</h3>
                    <p class="abtinfo3">Donor go to the <a href="<?php echo $sublink_h; ?>" class="abtinfolink"> Donor Page</a> and fill the Form and Submit the form. The people who need that Food they will contact<br>
                    them and send the request.</p>
                </p>
            </div>
        </div>

        <div class="end">
            <div class="fms">
                <h1>FOOD</h1>
                <h1>MANAGEMENT</h1>
            </div>

            <div class="endlinks">
                <ul>
                    <li class="endlink"><a href="<?php echo $sublink_b; ?>" class="endlinks1">About Us</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_c; ?>" class="endlinks1">Contact</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_d; ?>" class="endlinks1">Donor</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_f; ?>" target="_main" class="endlinks1">Hunger Fact</a></li>
                </ul>
            </div>

            <div class="follow" style="padding-left: ;float: right;margin-left: 40%;margin-top: 5%;">
            <nav class="media">
                <!-- <h3 style="color:white; font-size:20px;">Follow Us</h3> -->
                <!-- <a href="https://in.linkedin.com/in/vishal-burud?original_referer=https%3A%2F%2Fwww.google.com%2F" target="_main"><img src="/linkdin.png"></a> -->
                <a href="mailto:burudvishal07@gmail.com" target="_main"><img src="/FMS/follow/mail.png"></a>
                <a href="https://www.instagram.com/vishalburud.81/" target="_main"><img src="/FMS/follow/insta.png"></a>
                <a href="https://www.instagram.com/vishalburud.81/" target="_main"><img src="/FMS/follow/facebook.png"></a>
                <a href="" target="_main"><img src="/FMS/follow/twitter.png"></a>
                <!-- <a href="tel:+91 7218655640"><img src="/call.png"></a> -->
            </nav>
        </div>
        </div>
    </div>
</body>
</html>