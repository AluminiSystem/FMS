<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "fms";
$conn = mysqli_connect($servername, $username, $password, $database);

if($conn){
    // echo "success";
}
?>