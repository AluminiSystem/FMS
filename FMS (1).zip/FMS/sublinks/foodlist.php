<?php
// INSERT INTO `donar` (`sno`, `food_item`, `pickup_date`, `pickup_address`, `city`, `state`, `phone`, `email`, `message`, `time_stamp`) VALUES ('1', 'Chapati, Rice', '2023-05-02 08:15:34.000000', 'Trishul Chowk Ichalkarnji', 'Ichalkarnji', 'Maharashtra', '7218655640', 'burudvishal07@gmail.com', 'Hiii If you want food then contact mee Immediatly.', '2023-05-02 08:15:34.000000');
//Connect to database
$servername = "localhost";
$username = "root";
$password = "";
$database = "fms";
$conn = mysqli_connect($servername, $username, $password, $database);
?>
<!doctype html>
<html lang="en">
    <?php
    
        $sublink_a = "/FMS/sublinks/home.php";
        $sublink_b = "/FMS/sublinks/about.php";
        $sublink_c = "/FMS/sublinks/contact.php";
        $sublink_d = "/FMS/sublinks/donar.php";
        $sublink_e = "/FMS/sublinks/signup.php";
        $sublink_f = "https://www.actionagainsthunger.org/the-hunger-crisis/world-hunger-facts/";
        $sublink_g = "/FMS/sublinks/foodlist.php";
        $sublink_h = "/FMS/sublinks/login.php";
    ?>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Available Food | Food Management</title>
    <link rel="stylesheet" href="/FMS/fms.css">
  </head>
  <body>

  <div class="listcontainer">
    <div class="head">
    <ul class="dashboard">
                <li class="dash"><a href="<?php echo $sublink_a; ?>" class="sublink">Home</a></li>
                <li class="dash"><a href="<?php echo $sublink_b; ?>" class="sublink">About</a></li>
                <li class="dash"><a href="<?php echo $sublink_h; ?>" class="sublink">Donar</a></li>
                <li class="dash"><a href="<?php echo $sublink_g; ?>" class="sublink">Available Food List</a></li>
                <li class="dash"><a href="<?php echo $sublink_c; ?>" class="sublink">Contact</a></li>
                <li class="dash"><a href="<?php echo $sublink_e; ?>" class="sublink sublink1">Register/Login</a></li>
            </ul>
    </div>


<div class="foodlist" style="margin-top:60px;">
<table class="table table-striped" style="border-top:1px solid black;">
  <thead>
    <tr>
      <th scope="col">Food Item</th>
      <th scope="col">Pickup Date</th>
      <th scope="col">Pickup Address</th>
      <th scope="col">City</th>
      <th scope="col">State</th>
      <th scope="col">Contact</th>
      <th scope="col">Email</th>
      <th scope="col">Message</th>
    </tr>
  </thead>
  <tbody>
    <?php
      $sql = "SELECT * FROM `donar`";
      $result = mysqli_query($conn, $sql);
      while($row = mysqli_fetch_assoc($result)){
        echo "<tr>
              <th scope='row'>". $row['food_item'] ."</th>
              <td>". $row['pickup_date'] ."</td>
              <td>". $row['pickup_address'] ."</td>
              <td>". $row['city'] ."</td>
              <td>". $row['state'] ."</td>
              <td>". $row['phone'] ."</td>
              <td>". $row['email'] ."</td>
              <td>". $row['message'] ."</td>
              </tr>";
      }
    ?> 
  <tbody>
</table>


    </div>

      <!-- <div class="end">
            <div class="fms">
                <h1>FOOD</h1>
                <h1>MANAGEMENT</h1>
            </div>

            <div class="endlinks">
                <ul>
                    <li class="endlink"><a href="<?php echo $sublink_b; ?>" class="endlinks1">About Us</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_c; ?>" class="endlinks1">Contact</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_d; ?>" class="endlinks1">Donor</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_f; ?>" target="_main" class="endlinks1">Hunger Fact</a></li>
                </ul>
            </div>

            <div class="follow" style="padding-left: ;float: right;margin-left: 40%;margin-top: 5%;">
            <nav class="media">
                 <h3 style="color:white; font-size:20px;">Follow Us</h3> -->
                <!-- <a href="https://in.linkedin.com/in/vishal-burud?original_referer=https%3A%2F%2Fwww.google.com%2F" target="_main"><img src="/linkdin.png"></a> -->
                <!-- <a href="mailto:burudvishal07@gmail.com" target="_main"><img src="/FMS/follow/mail.png"></a>
                <a href="https://www.instagram.com/vishalburud.81/" target="_main"><img src="/FMS/follow/insta.png"></a>
                <a href="https://www.instagram.com/vishalburud.81/" target="_main"><img src="/FMS/follow/facebook.png"></a>
                <a href="" target="_main"><img src="/FMS/follow/twitter.png"></a> -->
                <!-- <a href="tel:+91 7218655640"><img src="/call.png"></a> -->
            <!-- </nav> -->
        <!-- </div> -->
      <!-- </div> -->

    </div>
   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    
  </body>
</html>
