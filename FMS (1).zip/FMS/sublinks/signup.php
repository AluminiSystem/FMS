<?php

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $err = "";
    include 'dbconnect.php';
    $uname = $_POST['uname'];
    $dob = $_POST['dob'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $cpass = $_POST['cpass'];
    // $exists=false;

    //check whether username is exists
    $existSql = "SELECT * FROM `signupinfo` WHERE username = '$uname'";
    $result = mysqli_query($conn, $existSql);
    $numExistRows = mysqli_num_rows($result);
    if($numExistRows > 0){
        echo '<script>alert("Sorry! Username already Exists")</script>';
    } 
    else{

    if(($pass == $cpass)){
        $sql = "INSERT INTO `signupinfo` (`username`, `dob`, `email`, `password`, `date`, `cpassword`) VALUES ('$uname', '$dob', '$email', '$pass', current_timestamp(),'$cpass')";
        $result = mysqli_query($conn, $sql);
        if($result){
            echo '<script>alert("Success! Your account is now created and you can login")</script>';
        }
    }
    else{
        echo '<script>alert("Warning! Your password do not match. Please enter correct password")</script>';
    }
}
    
}

?>

<!DOCTYPE html>
<html lang="en">
<?php
        $sublink_a = "/FMS/sublinks/home.php";
        $sublink_b = "/FMS/sublinks/about.php";
        $sublink_c = "/FMS/sublinks/contact.php";
        $sublink_d = "/FMS/sublinks/donar.php";
        $sublink_e = "/FMS/sublinks/signup.php";
        $sublink_f = "https://www.actionagainsthunger.org/the-hunger-crisis/world-hunger-facts/";
        $sublink_g = "/FMS/sublinks/foodlist.php";
        $sublink_h = "/FMS/sublinks/login.php";
        $sublink_h = "/FMS/sublinks/login.php";
    ?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SignUp | Food Management</title>
    <link rel="stylesheet" href="/FMS/sublinks/fmsform.css">
    <link rel="stylesheet" href="/FMS/fms.css">
</head>
<body>
    <div class="login">

        <div class="head">
            <ul class="dashboard">
                        <li class="dash"><a href="<?php echo $sublink_a; ?>" class="sublink">Home</a></li>
                        <li class="dash"><a href="<?php echo $sublink_b; ?>" class="sublink">About</a></li>
                        <li class="dash"><a href="<?php echo $sublink_h; ?>" class="sublink">Donar</a></li>
                        <li class="dash"><a href="<?php echo $sublink_g; ?>" class="sublink">Available Food List</a></li>
                        <li class="dash"><a href="<?php echo $sublink_c; ?>" class="sublink">Contact</a></li>
                        <li class="dash"><a href="<?php echo $sublink_e; ?>" class="sublink sublink1">Register/Login</a></li>
            </ul>
        </div>    
        
        <h2 class="forminfohead">SignUp to Donate Food</h2>
        <div class="forminfo">
            <form action="\FMS\sublinks\signup.php" method="post">
            <div class="forminfo1">
                <div class="label">
                    <label for="uname" class="label1">Username</label>
                </div>
                <div class="input">
                    <input type="text" placeholder="Enter Username" name="uname" required>
                </div>

                <div class="label">
                    <label for="dob" class="label1">DOB</label>
                </div>
                <div class="input">
                    <input type="date" placeholder="Enter DOB" name="dob" required>
                </div>

                <div class="label">
                    <label for="email" class="label1">Email</label>
                </div>
                <div class="input">
                    <input type="mail" placeholder="Enter Email" name="email" required>
                </div>

                <div class="label">
                    <label for="pass" class="label1">Password</label>
                </div>
                <div class="input">
                    <input type="password" placeholder="Enter Password" name="pass" required>
                </div>

                <div class="label">
                    <label for="cpass" class="label1">Confirm Password</label>
                </div>
                <div class="input">
                    <input type="password" placeholder="Enter Password" name="cpass" required>
                </div>

                <button type="submit" class="btn">SignUp</button>
            </div>

                <div class="loglink">
                <a href="<?php echo $sublink_h;?>" class="loglink1">Login</a>
                </div>
            </form>
        </div>



        <div class="end">
            <div class="fms">
                <h1>FOOD</h1>
                <h1>MANAGEMENT</h1>
            </div>

            <div class="endlinks">
                <ul>
                    <li class="endlink"><a href="<?php echo $sublink_b; ?>" class="endlinks1">About Us</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_c; ?>" class="endlinks1">Contact</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_d; ?>" class="endlinks1">Donor</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_f; ?>" target="_main" class="endlinks1">Hunger Fact</a></li>
                </ul>
            </div>

            <div class="follow" style="padding-left: ;float: right;margin-left: 40%;margin-top: 5%;">
            <nav class="media">
                <!-- <h3 style="color:white; font-size:20px;">Follow Us</h3> -->
                <!-- <a href="https://in.linkedin.com/in/vishal-burud?original_referer=https%3A%2F%2Fwww.google.com%2F" target="_main"><img src="/linkdin.png"></a> -->
                <a href="mailto:burudvishal07@gmail.com" target="_main"><img src="/FMS/follow/mail.png"></a>
                <a href="https://www.instagram.com/vishalburud.81/" target="_main"><img src="/FMS/follow/insta.png"></a>
                <a href="https://www.instagram.com/vishalburud.81/" target="_main"><img src="/FMS/follow/facebook.png"></a>
                <a href="" target="_main"><img src="/FMS/follow/twitter.png"></a>
                <!-- <a href="tel:+91 7218655640"><img src="/call.png"></a> -->
            </nav>
        </div>
      </div>


    </div>
</body>
</html>