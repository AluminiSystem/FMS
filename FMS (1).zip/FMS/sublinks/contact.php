<!doctype html>
<html lang="en">
<?php
        $sublink_a = "/FMS/sublinks/home.php";
        $sublink_b = "/FMS/sublinks/about.php";
        $sublink_c = "/FMS/sublinks/contact.php";
        $sublink_d = "/FMS/sublinks/donar.php";
        $sublink_e = "/FMS/sublinks/signup.php";
        $sublink_f = "https://www.actionagainsthunger.org/the-hunger-crisis/world-hunger-facts/";
        $sublink_g = "/FMS/sublinks/foodlist.php";
        $sublink_h = "/FMS/sublinks/login.php";
    ?>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Contact Us | Food Management</title>
    <link rel="stylesheet" href="/FMS/fms.css">
  </head>
  <body>

  <div class="contcontainer continer">
    <div class="head">
    <ul class="dashboard">
                <li class="dash"><a href="<?php echo $sublink_a; ?>" class="sublink">Home</a></li>
                <li class="dash"><a href="<?php echo $sublink_b; ?>" class="sublink">About</a></li>
                <li class="dash"><a href="<?php echo $sublink_h; ?>" class="sublink">Donar</a></li>
                <li class="dash"><a href="<?php echo $sublink_g; ?>" class="sublink">Available Food List</a></li>
                <li class="dash"><a href="<?php echo $sublink_c; ?>" class="sublink">Contact</a></li>
                <li class="dash"><a href="<?php echo $sublink_e; ?>" class="sublink sublink1">Register/Login</a></li>
            </ul>
    </div>



<?php
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $desc = $_POST['desc'];
    $phone = $_POST['phone'];


    //conecting to the database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "fms";
    $conn = mysqli_connect($servername, $username, $password, $database);

    if(!$conn){
        die("Sorry We failed to Connect : " .mysqli_connect_error());
    }
    else{
        // echo "The Connection is Successfull!<br>";

        //submit these to database
        $sql = "INSERT INTO `contactus` (`name`, `email`, `concern`, `date`, `phone`) VALUES ('$name', '$email', '$desc', '$phone', current_timestamp())";
        $result = mysqli_query($conn, $sql);
        if($result){
          echo '<script>alert("Thank You! Your Details are Submitted Successfully! We will Contact you in a time:)")</script>';
        }
        else{
            echo "Data has Not inserted Successfully! bcz of this error------->" . mysqli_error($conn);
        }
    }
}
?>

    <div class="container mt-3 mb-5">
    <h2 class="c-#237a9c">Contact us for your Concern </h2>
    <form action="/FMS/sublinks/contact.php" method="post">
        <div class="mt-3">
          <label for="name" class="form-label">Name</label>
          <input type="text" name="name" class="form-control" id="name" aria-describedby="emailHelp" required>
          <!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->
        </div>

        <div class="mt-3">
          <label for="phone" class="form-label">Phone</label>
          <input type="tel" name="phone" class="form-control" id="phone" aria-describedby="emailHelp" required>
          <!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->
        </div>

        <div class="mt-3">
          <label for="email" class="form-label">Email</label>
          <input type="email" name="email" class="form-control" id="email" aria-describedby="emailHelp" required>
          <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
        </div>

        <div class="mt-2">
          <label for="desc" class="form-label">Your Message</label>
          <textarea class="form-control" name="desc" id="desc" cols="30" rows="5" required></textarea>
        </div>

        <!-- <div class="mt-2 form-check">
          <input type="checkbox" class="form-check-input" id="exampleCheck1">
          <label class="form-check-label" for="exampleCheck1">Check me out</label>
        </div> -->
        <button type="submit" class="btn btn-primary mt-3">Submit</button>
      </form>
    </div>


      <div class="end">
            <div class="fms">
                <h1>FOOD</h1>
                <h1>MANAGEMENT</h1>
            </div>

            <div class="endlinks">
                <ul>
                    <li class="endlink"><a href="<?php echo $sublink_b; ?>" class="endlinks1">About Us</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_c; ?>" class="endlinks1">Contact</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_d; ?>" class="endlinks1">Donor</a></li>
                    <li class="endlink"><a href="<?php echo $sublink_f; ?>" target="_main" class="endlinks1">Hunger Fact</a></li>
                </ul>
            </div>

            <div class="follow" style="padding-left: ;float: right;margin-left: 40%;margin-top: 5%;">
            <nav class="media">
                <!-- <h3 style="color:white; font-size:20px;">Follow Us</h3> -->
                <!-- <a href="https://in.linkedin.com/in/vishal-burud?original_referer=https%3A%2F%2Fwww.google.com%2F" target="_main"><img src="/linkdin.png"></a> -->
                <a href="mailto:burudvishal07@gmail.com" target="_main"><img src="/FMS/follow/mail.png"></a>
                <a href="https://www.instagram.com/vishalburud.81/" target="_main"><img src="/FMS/follow/insta.png"></a>
                <a href="https://www.instagram.com/vishalburud.81/" target="_main"><img src="/FMS/follow/facebook.png"></a>
                <a href="" target="_main"><img src="/FMS/follow/twitter.png"></a>
                <!-- <a href="tel:+91 7218655640"><img src="/call.png"></a> -->
            </nav>
        </div>
      </div>

      </div>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    
  </body>
</html>
